for i in range(101):
    print(f"HACKING PENTAGON {i}%")
